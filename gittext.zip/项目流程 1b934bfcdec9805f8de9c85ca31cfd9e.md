# 项目流程

```mermaid
flowchart TD
    A[开始] --> B{条件判断}
    B -->|条件成立| C[执行操作1]
    B -->|条件不成立| D[执行操作2]
    C --> E[结束]
    D --> E
```

**效果预览**：

```mermaid
flowchart TD
    A[开始] --> B{条件判断}
    B -->|条件成立| C[执行操作1]
    B -->|条件不成立| D[执行操作2]
    C --> E[结束]
    D --> E
```

```mermaid
flowchart LR
    Start --> Input[/输入学生信息/]
    Input --> Validate{是否合法?}
    Validate -->|是| Save[保存到文件]
    Validate -->|否| Error[显示错误提示]
    Save --> Exit[退出程序]
    Error --> Input
```

```mermaid
flowchart TB
    Start --> Loop[循环初始化]
    Loop --> Condition{是否满足条件?}
    Condition -->|是| Process[执行循环体]
    Process --> Update[更新循环变量]
    Update --> Condition
    Condition -->|否| Exit[退出循环]
```

```mermaid
flowchart TD
    A[开始]:::start --> B{判断}
    B -->|Yes| C[成功]:::success
    B -->|No| D[失败]:::error

    classDef start fill:#4CAF50,color:white;
    classDef success fill:#2196F3,color:white;
    classDef error fill:#f44336,color:white;
```

```mermaid
flowchart TB
    Start[启动程序] --> Load[从文件加载数据]
    Load --> Menu[显示菜单]
    Menu --> Input[/用户输入选项/]
    Input --> Choice{选择操作}
    Choice -->|添加学生| Add[执行添加]
    Choice -->|删除学生| Delete[执行删除]
    Choice -->|查询学生| Search[执行查询]
    Choice -->|退出程序| Save[保存数据到文件]
    Save --> Exit[退出]
    Add --> Menu
    Delete --> Menu
    Search --> Menu
```